/*
 * step-2.h
 *
 *  Created on: Jul 2, 2010
 *      Author: narayan
 */

#ifndef STEP2_H_
#define STEP2_H_

#include <vector>

#include "krawczyk-defs.h"
#include "box.h"
#include "base-predicate-inl.h"
#include "algorithm-inl.h"
#include "krawczyk2D-inl.h"
#include "newton2D-inl.h"
#include "hs2D-inl.h"

using namespace std;

namespace step2 {

template <typename NT>
void ConvertBF(vector<const BoxT<NT> *> *input,
               vector<const BoxT<BigFloat> *> *output,
               const NT perturb = 0.005)  {
  for (unsigned int i = 0; i < input->size(); ++i) {
    const BoxT<NT> *box = (*input)[i];
    BoxT<BigFloat> *box_bf = new BoxT<BigFloat>(
        0,
        IntervalT<BigFloat>(
            box->x_range.getL() - perturb,
            box->x_range.getR() + perturb),
        IntervalT<BigFloat>(
            box->y_range.getL() - perturb,
            box->y_range.getR() + perturb));
    output->push_back(box_bf);
    delete box;
  }
  input->clear();
}

template <typename NT>
void ReverseConvertBF(vector<const BoxT<BigFloat> *> *input,
               vector<const BoxT<NT> *> *output)  {
  for (unsigned int i = 0; i < input->size(); ++i) {
    const BoxT<BigFloat> *box = (*input)[i];
    BoxT<NT> *box_bf = new BoxT<NT>(
        0,
        IntervalT<NT>(
            NT(box->x_range.getL().doubleValue()),
            NT(box->x_range.getR().doubleValue())),
        IntervalT<NT>(
            NT(box->y_range.getL().doubleValue()),
            NT(box->y_range.getR().doubleValue())));
    output->push_back(box_bf);
    delete box;
  }
  input->clear();
}

const bool Adjacent(const BoxT<BigFloat> *b1, const BoxT<BigFloat> *b2) {
  const IntervalT<BigFloat> &x_1 = b1->x_range;
  const IntervalT<BigFloat> &y_1 = b1->y_range;

  const IntervalT<BigFloat> &x_2 = b2->x_range;
  const IntervalT<BigFloat> &y_2 = b2->y_range;

  return Overlap(x_1, x_2) && Overlap(y_1, y_2);
  /*
  const BigFloat &b1_xmin = b1->x_range.getL();
  const BigFloat &b1_xmax = b1->x_range.getR();
  const BigFloat &b1_ymin = b1->y_range.getL();
  const BigFloat &b1_ymax = b1->y_range.getR();

  const BigFloat &b2_xmin = b2->min_.re();
  const BigFloat &b2_xmax = b2->max_.re();
  const BigFloat &b2_ymin = b2->min_.im();
  const BigFloat &b2_ymax = b2->max_.im();

  // West or east
  if (b1_ymin == b2_ymin && (b1_xmax == b2_xmin || b1_xmin == b2_xmax)) {
    return true;
  }
  if (b1_xmin == b2_xmin && (b1_ymax == b2_ymin || b1_ymin == b2_ymax)) {
    return true;
  }

  return false;
  */
}

class ConnectedComponent {
  typedef BoxT<BigFloat> cBox;
 public:
  ConnectedComponent(const cBox *box) {
    member_boxes_.push_back(box);
    x_min = box->x_range.getL();
    x_max = box->x_range.getR();
    y_min = box->y_range.getL();
    y_max = box->y_range.getR();
  }

  void Add(const cBox *box) {
    // Add this to the list of boxes that make up this
    // connected component.
    member_boxes_.push_back(box);

    // Update the extent of this connected component.
    if (box->x_range.getL() < x_min) {
      x_min = box->x_range.getL();
    }
    if (box->y_range.getL() < y_min) {
      y_min = box->y_range.getL();
    }
    if (box->x_range.getR() > x_max) {
      x_max = box->x_range.getR();
    }
    if (box->y_range.getR() > y_max) {
      y_max = box->y_range.getR();
    }
  }

  void AddAll(ConnectedComponent *c) {
    for (unsigned int i = 0; i < c->member_boxes_.size(); ++i) {
      Add(c->member_boxes_[i]);
    }
  }

  bool Connected(const cBox *box) {
    vector<const cBox *>::const_iterator it = member_boxes_.begin();
    while (it != member_boxes_.end()) {
      const cBox *b = (*it);
      if (Adjacent(b, box)) {
        return true;
      }
      ++it;
    }

    return false;
  }

  const cBox *BoundingBox() {
    return new BoxT<BigFloat>(0, IntervalT<BigFloat>(x_min, x_max),
                              IntervalT<BigFloat>(y_min, y_max));
  }
  ~ConnectedComponent() {
    for (unsigned int i = 0; i < member_boxes_.size(); ++i) {
     // delete member_boxes_[i];
    }
  }

  vector<const cBox *> member_boxes_;
  BigFloat x_min, y_min;
  BigFloat x_max, y_max;
};

void CoalesceBoxes(vector<const BoxT<BigFloat> *> *input) {
  list<ConnectedComponent *> components;

  vector<const BoxT<BigFloat> *>::const_iterator it = input->begin();
  components.push_back(new ConnectedComponent(*it));
  ++it;

  vector<ConnectedComponent *> matching_comps;
  while (it != input->end()) {
    const BoxT<BigFloat> *b = (*it);
    matching_comps.clear();

    list<ConnectedComponent *>::iterator c_it = components.begin();
    while (c_it != components.end()) {
      ConnectedComponent *comp = (*c_it);
      if (comp->Connected(b)) {
        matching_comps.push_back(comp);
        c_it = components.erase(c_it);
        continue;
      }
      ++c_it;
    }

    if (matching_comps.size() == 1) {
      components.push_back(matching_comps[0]);
      matching_comps[0]->Add(b);
    } else if (matching_comps.size() != 0) {
      ConnectedComponent *comp = matching_comps.back();
      matching_comps.pop_back();

      for (unsigned int i = 0; i < matching_comps.size(); ++i) {
        comp->AddAll(matching_comps[i]);
        delete matching_comps[i];
      }

      comp->Add(b);
      components.push_back(comp);
    } else {
      components.push_back(new ConnectedComponent(b));
    }
    ++it;
  }

  input->clear();
  list<ConnectedComponent *>::iterator c_it = components.begin();
  while (c_it != components.end()) {
    ConnectedComponent *comp = (*c_it);
    input->push_back(comp->BoundingBox());
    ++c_it;
    delete comp;
  }
}

enum operator_type {
  NEWTON,
  KRAWCZYK,
  HANSEN,
};

template <typename NT>
void ConvertPoly(Polynomial<BigFloat> *output,
    const Polynomial<BigFloat> &in) {
  vector<BigFloat> coeff_array;
  for (int i = 0; i < in.getDegree() + 1; ++i) {
    coeff_array.push_back(in.coeff()[i]);
  }
  (*output) = Polynomial<BigFloat>(coeff_array);
}

template <typename NT>
BiPoly<BigFloat> ConvertPoly(const BiPoly<NT> &p) {
  vector<Polynomial<BigFloat> > coeff_array(p.getYdegree() + 1);
  for (int i = 0; i < p.getYdegree() + 1; ++i) {
    ConvertPoly<NT>(&coeff_array[i], p.coeffX[i]);
  }
  return BiPoly<BigFloat>(coeff_array);
}

template <typename NT>
void Process(vector<const BoxT<NT> *> *unresolved,
             vector<const BoxT<NT> *> *output,
             const BiPoly<NT> &fxy,
             const BiPoly<NT> &gxy,
             const NT &max_size,
             const NT &min_size,
             const operator_type op_type) {
  if (unresolved->size() == 0) {
    return;
  }

  vector<const BoxT<BigFloat> *> unresolved_2;
  ConvertBF<NT>(unresolved, &unresolved_2);
  CoalesceBoxes(&unresolved_2);

  BiPoly<BigFloat> fxy_2 = ConvertPoly<NT>(fxy);
  BiPoly<BigFloat> gxy_2 = ConvertPoly<NT>(gxy);
  BasePredicate<BigFloat> *pred_2 = NULL;

  if (op_type == NEWTON) {
    pred_2 = new Newton2D<BigFloat>(fxy_2, gxy_2 , max_size,
        0, 4, 0);
  } else if (op_type == KRAWCZYK) {
    pred_2 = new Krawczyk2D<BigFloat>(fxy_2, gxy_2 , max_size,
        0, 4, 0);
  } else {
    pred_2 = new Hs2D<BigFloat>(fxy_2, gxy_2 , max_size,
        0, 4, 0);
  }

  vector<const BoxT<BigFloat> *> output_2;
  vector<const BoxT<BigFloat> *> ambiguous_2;
  cout << endl << "Running step 2 : " << endl;
  for (unsigned int i = 0; i < unresolved_2.size(); ++i) {
    cout << "Box:" << unresolved_2[i]->x_range << "," << unresolved_2[i]->y_range << endl;
    Algorithm::Run<BigFloat>(*pred_2, unresolved_2[i], &output_2, NULL, &ambiguous_2
        , false);
  }

  ReverseConvertBF<NT>(&output_2, output);

  delete pred_2;
}


}  // namespace step2;

#endif /* STEP2_H_ */
