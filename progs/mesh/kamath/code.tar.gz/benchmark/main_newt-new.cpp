
//#ifndef CORE_LEVEL
// #define CORE_LEVEL 1
//#endif

#include "tclap/CmdLine.h"
#include <sys/time.h>

#include "../krawczyk/krawczyk-defs.h"
#include "CORE/CORE.h"
#include "CORE/poly/Curves.h"
#include "CORE/linearAlgebraT.h"

#include "../krawczyk/default-functions-inl.h"

// Krawczyk
#include "../krawczyk/krawczyk2D-inl.h"
#include "../krawczyk/newton2D-inl.h"
#include "../krawczyk/hs2D-inl.h"
#include "../krawczyk/algorithm-inl.h"

#include "../krawczyk/tmp-display.h"

#include "benchmark.h"

void startGlutLoop(int argc, char **argv) {
  cout << "-------------Graphic----------------"<<endl;
  cout << "--------Press ESC to exit-----------"<<endl;

  // Various open GL related things.
  glutInit(&argc, argv);
  glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
  glutInitWindowSize(600, 600);
  glutInitWindowPosition(100, 100);
  glutCreateWindow("CXY       (Press ESC to exit)");
  display_funcs::ClearBackground();
  glutReshapeFunc(display_funcs::ReshapeHandler);
  glutDisplayFunc(display_funcs::DisplayHandler);
  glutKeyboardFunc(display_funcs::KeyHandler);
  glutMainLoop();
}

int main(int argc, char **argv) {
  TCLAP::ValueArg<string> x_min("x", "x_min", "Minimum x range", false, "-2", "string");
  TCLAP::ValueArg<string> x_max("c", "x_max", "Maximum x range", false, "2", "string");
  TCLAP::ValueArg<string> y_min("y", "y_min", "Minimum y range", false, "-2", "string");
  TCLAP::ValueArg<string> y_max("u", "y_max", "Maximum y range", false, "2", "string");
  TCLAP::ValueArg<string> poly("p", "poly", "Input polynomial file name", true, "", "string");
  TCLAP::ValueArg<string> min_box_size(
      "m", "min_box_size", "Minimum subdivision size", false, "0.001", "string");
  TCLAP::ValueArg<string> max_box_size(
      "l", "max_box_size", "Maximum subdivision size", false, "0.1", "string");
  TCLAP::ValueArg<int> cthresh("t", "cr_threshold",
      "Threshold for recalculating the centered form", false, 4, "int");
  TCLAP::ValueArg<int> max_gen("g", "max_gen_id",
      "Threshold for recalculating the centered form", false, 10, "int");


  TCLAP::SwitchArg use_rb("r", "use_root_bounds", "Use Cauchy Bounds", false);
  TCLAP::SwitchArg display("d", "display", "Display subdivision tree", false);
  TCLAP::SwitchArg use_newton("n", "newton", "Use newton iteration", false);
  TCLAP::SwitchArg use_krawczyk("k", "krawczyk", "Use the krawczyk operator", false);
  TCLAP::SwitchArg use_hs("s", "hansen", "Use the hansen sengupta operator", false);

  try {
     TCLAP::CmdLine cmd("Newton type methods", ' ', "0.1");
     cmd.add(poly);
     cmd.add(x_min);
     cmd.add(x_max);
     cmd.add(y_min);
     cmd.add(y_max);
     cmd.add(use_rb);
     cmd.add(display);
     cmd.add(use_newton);
     cmd.add(use_krawczyk);
     cmd.add(use_hs);
     cmd.add(min_box_size);
     cmd.add(max_box_size);
     cmd.add(cthresh);
     cmd.add(max_gen);

     // Parse the args.
     cmd.parse(argc, argv);

     // Get the value parsed by each arg.
     //string name = nameArg.getValue();
   } catch (TCLAP::ArgException &e) {
     cerr << "Error : " << e.error() << endl;
     cerr << "Processing arg : " << e.argId() << endl;
     return -1;
   }

  const double x_min_d(x_min.getValue()),
      x_max_d(x_max.getValue()), y_min_d(y_min.getValue()),
      y_max_d(y_max.getValue());
  const double min_size(min_box_size.getValue());
  const double max_size(max_box_size.getValue());

  BiPoly<double> fxy;
  BiPoly<double> gxy;
  benchmark::GetBiPoly(poly.getValue().c_str(), &fxy, &gxy);

  // Input box
  Interval x_range(x_min_d, x_max_d);
  Interval y_range(y_min_d, y_max_d);

  // start timing code.
  struct timeval start;
  struct timeval end;
  gettimeofday(&start, NULL);
  // end timing code.

  Box *B0 = new Box(0, new Interval(x_range), new Interval(y_range));

  // Output types.
  std::vector<const Box *> output;
  std::vector<const Box *> ambiguous;
  std::vector<const Box *> exclude;

  std::vector<const Box *> *exclude_ptr = NULL;
  if (display.getValue()) {
    exclude_ptr = &exclude;
  }

  if (use_krawczyk.getValue()) {
    Krawczyk2D k_pred(fxy, gxy, max_size, min_size, max_gen.getValue(),
        cthresh.getValue());
    Algorithm::Run<Krawczyk2D, Box>(
        k_pred, B0, &output, exclude_ptr, &ambiguous);

  } else if (use_newton.getValue()) {
    Newton2D n_pred(fxy, gxy, max_size, min_size, max_gen.getValue(),
        cthresh.getValue());
    Algorithm::Run<Newton2D, Box>(
        n_pred, B0, &output, exclude_ptr, &ambiguous);

  } else if (use_hs.getValue()) {
    Hs2D h_pred(fxy, gxy, max_size, min_size, max_gen.getValue(),
        cthresh.getValue());
    Algorithm::Run<Hs2D, Box>(
        h_pred, B0, &output, exclude_ptr, &ambiguous);
  } else {
    cout << "Please specify one of -n (newton) -s (hansen-sengupta) or -k (krawczyk)" << endl;
    return 0;
  }

  // start timing code.
  gettimeofday(&end, NULL);
  cout << "The total time taken : " <<
      (end.tv_sec - start.tv_sec)*1000000 + (end.tv_usec - start.tv_usec) << " micro seconds" << endl;

  if (display.getValue()) {
    cout << endl << "Operating over : " << x_range << "," << y_range << endl;
    cout << "With polynomials : " << endl;
    cout << endl;
    fxy.dump();
    cout << endl;
    gxy.dump();

    cout << endl << "Output regions : " << endl;
    for (unsigned int i = 0 ; i < output.size(); ++i) {
      const Box *interval = output[i];
      cout << "X : " << *(interval->x_range) << ", Y : " << *(interval->y_range) << endl;
    }


    cout << endl << "Unresolved regions : " << endl;
    for (unsigned int i = 0 ; i < ambiguous.size(); ++i) {
      const Box *interval = ambiguous[i];
      cout << "X : " << *(interval->x_range) << ", Y : " << *(interval->y_range) << endl;
    }


    Box *display = new Box(0, new Interval(x_range), new Interval(y_range));
    display_funcs::SetDisplayParams(display, &exclude, &output, &ambiguous);
    startGlutLoop(argc, argv);
    delete display;
  } else {
    cout << "Num roots : " << output.size() << endl;
  }

  return 0;
}
