import os;
import subprocess;

X_MIN = -2.5
X_MAX = 2.5
Y_MIN = -2.5
Y_MAX = 2.5
THRESH = [0, 2, 4, 8, 16, 32 , 64] 

def main():
      for thresh in THRESH:
        print ("%s" % thresh)
        args = []
        args.append("./main_newt")
        args.append("-k")
        args.append("--poly %s" % "./data/laguerre20.pol")
        args.append("--x_min %s" % X_MIN)
        args.append("--x_max %s" % X_MAX)
        args.append("--y_min %s" % Y_MIN)
        args.append("--y_max %s" % Y_MAX)
        args.append("--cr_threshold %d" % thresh)
       
        # args.append("--step_2")
        process = subprocess.Popen(args)
        process.wait()
        print "-----------------------------" 


if __name__ == "__main__":
  main()
