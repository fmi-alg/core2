import random

def main():
  print random
  randoms = []
  for i in range(1, 50):
    randoms.append(random.randint(0, 1000000))
  print randoms

if __name__ == "__main__":
  main()
